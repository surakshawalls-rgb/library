import { Component, Inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialogModule, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule } from '@angular/material/core';
import { MatSelectModule } from '@angular/material/select';
import { MatRadioModule } from '@angular/material/radio';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { LibrarySeat, LibraryService } from '../../services/library.service';
import { addDays, getDaysInMonth, startOfDay } from 'date-fns';

export interface RegistrationDialogData {
  seat?: LibrarySeat | null;
  canViewPersonalDetails: boolean;
  mode?: 'seat_registration' | 'public_request';
  title?: string;
  submitLabel?: string;
  allowExistingStudentLookup?: boolean;
}

export interface RegistrationResult {
  name: string;
  mobile: string;
  emergency_contact: string;
  emergency_contact_name: string;
  address: string;
  dob: Date | null;
  gender: 'Male' | 'Female';
  startDate: Date;
  endDate: Date;
  registration_fee_paid: number;
  notes: string;
  selectedShift: 'full_time' | 'first_half' | 'second_half';
  feeAmount: number;
  paymentMode: 'cash' | 'upi' | 'card';
  isPaymentReceived: boolean;
}

@Component({
  selector: 'app-registration-dialog',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MatDialogModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatFormFieldModule,
    MatInputModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatSelectModule,
    MatRadioModule,
    MatProgressSpinnerModule,
  ],
  providers: [
    MatDatepickerModule,
    MatNativeDateModule
  ],
  template: `
    <h2 mat-dialog-title>{{ dialogTitle }}</h2>
    
    <mat-dialog-content>
      <form [formGroup]="registrationForm" class="registration-form">
        <div *ngIf="isPublicRequestMode" class="public-request-banner full-width">
          <strong>Manual payment workflow:</strong>
          After you submit this request, the library team will verify payment manually and assign a seat after approval.
        </div>

        <mat-form-field appearance="outline">
          <mat-label>Full Name</mat-label>
          <input matInput formControlName="name" placeholder="Enter full name" required>
          <mat-error *ngIf="registrationForm.get('name')?.hasError('required')">
            Name is required
          </mat-error>
        </mat-form-field>

        <mat-form-field appearance="outline" *ngIf="data.canViewPersonalDetails">
          <mat-label>Mobile Number</mat-label>
          <input matInput formControlName="mobile" type="tel" maxlength="10" placeholder="10-digit mobile" required>
          <mat-error *ngIf="registrationForm.get('mobile')?.hasError('required')">
            Mobile number is required
          </mat-error>
          <mat-error *ngIf="registrationForm.get('mobile')?.hasError('pattern')">
            Must be exactly 10 digits
          </mat-error>
        </mat-form-field>

        <mat-form-field appearance="outline" *ngIf="data.canViewPersonalDetails">
          <mat-label>Emergency Contact</mat-label>
          <input matInput formControlName="emergency_contact" type="tel" maxlength="10" placeholder="10-digit mobile">
          <mat-error *ngIf="registrationForm.get('emergency_contact')?.hasError('pattern')">
            Must be exactly 10 digits
          </mat-error>
        </mat-form-field>

        <mat-form-field appearance="outline" *ngIf="data.canViewPersonalDetails">
          <mat-label>Emergency Contact Name</mat-label>
          <input matInput formControlName="emergency_contact_name" placeholder="Parent/Guardian name">
        </mat-form-field>

        <div class="form-group">
          <mat-form-field class="example-form-field" appearance="outline" style="width: 100%;">
            <mat-label>Date of Birth</mat-label>
            <input matInput [matDatepicker]="datepicker" formControlName="dob" />
            <mat-hint>MM/DD/YYYY</mat-hint>
            <mat-datepicker-toggle matIconSuffix [for]="datepicker"></mat-datepicker-toggle>
            <mat-datepicker #datepicker>
              <mat-datepicker-actions>
                <button matButton matDatepickerCancel>Cancel</button>
                <button matButton="elevated" matDatepickerApply>Apply</button>
              </mat-datepicker-actions>
            </mat-datepicker>
            <mat-error *ngIf="registrationForm.get('dob')?.invalid && registrationForm.get('dob')?.touched">
              Date of Birth is required
            </mat-error>
          </mat-form-field>
        </div>

        <!-- Professional Toggle Button Section -->
        <div class="toggle-section">
          <div class="toggle-row">
            <label class="group-label">Gender</label>
            <mat-button-toggle-group formControlName="gender" class="toggle-group">
              <mat-button-toggle value="Male">👨 Male</mat-button-toggle>
              <mat-button-toggle value="Female">👩 Female</mat-button-toggle>
            </mat-button-toggle-group>
          </div>
        </div>
        <!-- End of Professional Toggle Button Section -->

        <div class="form-group full-width date-range">

          <mat-form-field class="example-form-field" appearance="outline" style="width: 100%;">
            <mat-label>Start Date</mat-label>
            <input matInput [matDatepicker]="startPicker" formControlName="startDate" placeholder="Start date" (dateChange)="onStartDateChange($event)" />
            <mat-datepicker-toggle matIconSuffix [for]="startPicker"></mat-datepicker-toggle>
            <mat-datepicker #startPicker></mat-datepicker>
            <mat-error *ngIf="registrationForm.get('startDate')?.invalid && registrationForm.get('startDate')?.touched">
              Start date is required
            </mat-error>
          </mat-form-field>
          <mat-form-field class="example-form-field" appearance="outline" style="width: 100%;">
            <mat-label>End Date</mat-label>
            <input matInput [matDatepicker]="endPicker" formControlName="endDate" placeholder="End date" />
            <mat-datepicker-toggle matIconSuffix [for]="endPicker"></mat-datepicker-toggle>
            <mat-datepicker #endPicker></mat-datepicker>
            <mat-error *ngIf="registrationForm.get('endDate')?.invalid && registrationForm.get('endDate')?.touched">
              End date is required
            </mat-error>
          </mat-form-field>
        </div>

        <mat-form-field appearance="outline">
          <mat-label>Registration Fee</mat-label>
          <input matInput type="number" formControlName="registration_fee_paid" placeholder="Enter amount">
        </mat-form-field>

        <div class="form-group full-width">
          <label class="group-label">Shift Type</label>
          <mat-button-toggle-group formControlName="selectedShift" (change)="onShiftChange()" class="full-width-toggle">
            <mat-button-toggle value="full_time" *ngIf="isShiftAvailable('full_time')">🕐 Full Day</mat-button-toggle>
            <mat-button-toggle value="first_half" *ngIf="isShiftAvailable('first_half')">🌅 Morning</mat-button-toggle>
            <mat-button-toggle value="second_half" *ngIf="isShiftAvailable('second_half')">🌃 Evening</mat-button-toggle>
          </mat-button-toggle-group>
        </div>

        <mat-form-field appearance="outline">
          <mat-label>Fee Amount (₹)</mat-label>
          <input matInput type="number" formControlName="feeAmount" placeholder="Default: 250/400" required>
          <mat-hint>Default: ₹250 (Half Day), ₹400 (Full Day) - Editable</mat-hint>
          <mat-error *ngIf="registrationForm.get('feeAmount')?.hasError('required')">
            Fee amount is required
          </mat-error>
          <mat-error *ngIf="registrationForm.get('feeAmount')?.hasError('min')">
            Fee must be at least ₹1
          </mat-error>
        </mat-form-field>

        <div class="form-group full-width" *ngIf="!isPublicRequestMode">
          <label class="group-label">Seat Fee Received Today?</label>
          <mat-button-toggle-group formControlName="isPaymentReceived" class="full-width-toggle">
            <mat-button-toggle [value]="true">✅ Paid</mat-button-toggle>
            <mat-button-toggle [value]="false">⏳ Not Paid Yet</mat-button-toggle>
          </mat-button-toggle-group>
          <small class="pending-help" *ngIf="registrationForm.get('isPaymentReceived')?.value === false">
            Student will be registered and seat will be assigned, but payment status will stay pending until you collect fee.
          </small>
        </div>

        <div class="form-group">
          <label class="group-label">Payment Mode</label>
          <mat-button-toggle-group formControlName="paymentMode" class="full-width-toggle">
            <mat-button-toggle value="cash">💵 Cash</mat-button-toggle>
            <mat-button-toggle value="upi">📱 UPI</mat-button-toggle>
            <mat-button-toggle value="card">💳 Card</mat-button-toggle>
          </mat-button-toggle-group>
        </div>

        <mat-form-field appearance="outline" class="full-width" *ngIf="data.canViewPersonalDetails">
          <mat-label>Address</mat-label>
          <textarea matInput formControlName="address" rows="1" placeholder="Full address" required autoCapitalize="off" spellcheck="true"></textarea>
          <mat-error *ngIf="registrationForm.get('address')?.hasError('required')">
            Address is required
          </mat-error>
        </mat-form-field>

        <mat-form-field appearance="outline" class="full-width">
          <mat-label>Notes</mat-label>
          <textarea matInput formControlName="notes" rows="1" placeholder="Any additional notes" autoCapitalize="off" spellcheck="true"></textarea>
        </mat-form-field>
      </form>
    </mat-dialog-content>

    <mat-dialog-actions align="end">
      <button mat-button (click)="onCancel()">✖ Cancel</button>
      <button mat-raised-button color="primary" (click)="onSubmit()" [disabled]="!registrationForm.valid || saving">
        <mat-spinner diameter="18" *ngIf="saving" style="display: inline-block; margin-right: 8px; vertical-align: middle;"></mat-spinner>
        {{ saving ? 'Saving...' : submitButtonLabel }}
      </button>
    </mat-dialog-actions>
  `,
  styles: [`
    .registration-form {
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 16px;
      padding: 20px 0;
      min-width: 600px;
    }

    .full-width {
      grid-column: 1 / -1;
    }

    .date-range {
      grid-column: 1 / -1;
      display: grid;
      grid-template-columns: repeat(2, 1fr);
      gap: 16px;
    }

    .form-group {
      display: flex;
      flex-direction: column;
      gap: 8px;
    }

    .group-label {
      font-size: 13px;
      color: #333333;
      font-weight: 600;
      margin-bottom: 4px;
    }

    .public-request-banner {
      padding: 12px 14px;
      border-radius: 10px;
      background: #eff6ff;
      border: 1px solid #bfdbfe;
      color: #1d4ed8;
      font-size: 13px;
      line-height: 1.5;
    }

    .pending-help {
      color: #9a3412;
      background: #fff7ed;
      border: 1px solid #fed7aa;
      border-radius: 8px;
      padding: 8px 10px;
      font-size: 12px;
      line-height: 1.4;
    }

    .toggle-section {
      margin: 8px 0;
    }

    .toggle-row {
      display: flex;
      flex-direction: column;
      gap: 8px;
    }

    mat-button-toggle-group {
      width: 100%;
      border: 1px solid #dce0e4;
      border-radius: 8px;
      overflow: hidden;
    }

    .toggle-group {
      box-shadow: none;
    }

    .full-width-toggle {
      width: 100%;
      display: flex;
    }

    .full-width-toggle mat-button-toggle {
      flex: 1;
    }

    ::ng-deep .mat-button-toggle {
      border-right: 1px solid #dce0e4 !important;
    }

    ::ng-deep .mat-button-toggle:last-child {
      border-right: none !important;
    }

    ::ng-deep .mat-button-toggle-checked {
      background-color: #4CAF50 !important;
      color: white !important;
    }

    ::ng-deep .mat-button-toggle-label-content {
      line-height: 40px !important;
      padding: 0 16px !important;
      font-weight: 500;
      font-size: 14px;
    }

    .readonly-field input {
      cursor: default;
      color: rgba(0, 0, 0, 0.87);
      font-weight: 500;
    }

    .readonly-field ::ng-deep .mat-mdc-text-field-wrapper {
      background-color: #f5f7fa;
    }

    .readonly-field ::ng-deep .mat-mdc-form-field-focus-overlay {
      display: none;
    }

    mat-form-field {
      width: 100%;
    }

    ::ng-deep .mat-mdc-form-field {
      margin-bottom: 0 !important;
    }

    ::ng-deep .mat-mdc-text-field-wrapper {
      padding-bottom: 0 !important;
      background-color: white;
    }

    ::ng-deep .mat-mdc-form-field-infix {
      padding-top: 14px !important;
      padding-bottom: 14px !important;
    }

    ::ng-deep .mat-mdc-outlined-button:not(:disabled) {
      border-color: #dce0e4;
    }

    mat-dialog-content {
      overflow-y: auto;
      max-height: 64vh;
      padding: 0 24px 20px 24px;
      background: white;
      scrollbar-width: thin;
      scrollbar-color: #dce0e4 transparent;
    }

    mat-dialog-content::-webkit-scrollbar {
      width: 6px;
    }

    mat-dialog-content::-webkit-scrollbar-track {
      background: transparent;
    }

    mat-dialog-content::-webkit-scrollbar-thumb {
      background-color: #dce0e4;
      border-radius: 3px;
    }

    mat-dialog-title {
      padding: 20px 24px;
      margin: 0;
      background: white;
      border-bottom: 1px solid #dce0e4;
      font-size: 18px;
      font-weight: 600;
      color: #333333;
      flex-shrink: 0;
    }

    mat-dialog-actions {
      padding: 16px 24px;
      border-top: 1px solid #dce0e4;
      background: white;
      display: flex;
      justify-content: flex-end;
      gap: 12px;
      flex-shrink: 0;
      margin-top: auto;
    }

    button[mat-button] {
      min-width: 90px;
      font-weight: 500;
      border-radius: 8px;
      text-transform: none;
    }

    button[mat-raised-button] {
      min-width: 160px;
      font-weight: 500;
      border-radius: 8px;
      text-transform: none;
      box-shadow: 0 2px 8px rgba(76, 175, 80, 0.25);
    }

    button[mat-raised-button]:hover {
      box-shadow: 0 4px 12px rgba(76, 175, 80, 0.35);
    }

    ::ng-deep .mat-mdc-dialog-container {
      --mdc-dialog-container-color: white;
      display: flex !important;
      flex-direction: column !important;
      max-height: 90vh !important;
      border-radius: 12px !important;
      box-shadow: 0 8px 32px rgba(0,0,0,0.2) !important;
    }

    ::ng-deep .mat-mdc-dialog-surface {
      display: flex !important;
      flex-direction: column !important;
      border-radius: 12px !important;
      background: white !important;
    }

    ::ng-deep .mat-mdc-dialog-content {
      flex-grow: 1;
      overflow-y: auto;
    }

    ::ng-deep .mat-mdc-dialog-actions {
      flex-shrink: 0 !important;
    }

    ::ng-deep .mat-primary {
      --mdc-protected-button-container-color: #4CAF50;
      --mdc-protected-button-label-text-color: white;
    }

    ::ng-deep .mat-mdc-outlined-field {
      border-radius: 8px !important;
    }

    ::ng-deep .mat-mdc-form-field-focus-overlay {
      background-color: transparent;
    }

    ::ng-deep .mat-datepicker-toggle {
      color: #4CAF50;
    }

    ::ng-deep .mat-mdc-text-field-wrapper.mdc-text-field--outlined .mat-mdc-form-field-infix {
      padding-top: 14px;
      padding-bottom: 14px;
    }

    ::ng-deep textarea.mat-mdc-input-element {
      min-height: 40px;
      resize: vertical;
    }

    ::ng-deep .mat-mdc-form-field-hint,
    ::ng-deep .mat-mdc-form-field-error {
      font-size: 12px;
      margin-top: 4px;
    }

    input[readonly] {
      cursor: pointer !important;
      user-select: none;
    }

    ::ng-deep .mat-mdc-form-field {
      background-color: white;
    }

    ::ng-deep .mat-mdc-text-field-wrapper {
      background-color: white !important;
    }

    /* Mobile Responsive Styles */
    @media (max-width: 768px) {
      .registration-form {
        grid-template-columns: 1fr;
        min-width: unset;
        gap: 12px;
        padding: 16px 0;
      }

      .date-range {
        grid-template-columns: 1fr;
        gap: 12px;
      }

      mat-dialog-content {
        max-height: 70vh;
        padding: 0 12px 12px 12px;
        scrollbar-width: none;
        -ms-overflow-style: none;
      }

      mat-dialog-content::-webkit-scrollbar {
        display: none;
      }

      mat-dialog-title {
        padding: 12px;
        font-size: 16px;
      }

      mat-dialog-actions {
        padding: 10px 12px;
        flex-wrap: wrap;
      }

      button[mat-button] {
        min-width: auto;
        flex: 1;
      }

      button[mat-raised-button] {
        min-width: auto;
        flex: 1;
      }

      ::ng-deep .mat-button-toggle-label-content {
        line-height: 36px !important;
        padding: 0 12px !important;
        font-size: 13px;
      }

      ::ng-deep .mat-mdc-dialog-container {
        padding: 0 !important;
        margin: 0 !important;
      }

      ::ng-deep .mat-mdc-dialog-surface {
        border-radius: 0 !important;
        max-width: 100vw !important;
      }
    }

    @media (max-width: 480px) {
      .registration-form {
        gap: 10px;
        padding: 12px 0;
      }

      mat-dialog-content {
        padding: 0 8px 8px 8px;
        scrollbar-width: none;
        -ms-overflow-style: none;
      }

      mat-dialog-content::-webkit-scrollbar {
        display: none;
      }

      mat-dialog-title {
        padding: 10px 8px;
        font-size: 14px;
      }

      mat-dialog-actions {
        padding: 8px;
      }

      ::ng-deep .mat-button-toggle-label-content {
        line-height: 32px !important;
        padding: 0 8px !important;
        font-size: 12px;
      }

      ::ng-deep .mat-mdc-form-field-infix {
        padding-top: 12px !important;
        padding-bottom: 12px !important;
      }

      ::ng-deep .mat-mdc-dialog-container {
        padding: 0 !important;
        margin: 0 !important;
      }

      ::ng-deep .mat-mdc-dialog-surface {
        border-radius: 0 !important;
        max-width: 100vw !important;
      }
    }
  `]
})
export class RegistrationDialogComponent implements OnInit {
  onStartDateChange(event: any): void {
    const start: Date = event.value;
    if (start && (!this.registrationForm.get('endDate')?.value || this.registrationForm.get('endDate')?.pristine)) {
      // Get days in the start month using date-fns
      const daysInMonth = getDaysInMonth(start);
      
      // Calculate end date: start date + days in month - 1
      const end = addDays(start, daysInMonth - 1);
      
      this.registrationForm.get('endDate')?.setValue(end);
    }
  }

  // Removed flatpickr instances
  registrationForm!: FormGroup;
  saving = false;

  constructor(
    private fb: FormBuilder,
    public dialogRef: MatDialogRef<RegistrationDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: RegistrationDialogData,
    private libraryService: LibraryService
  ) {}

  get isPublicRequestMode(): boolean {
    return this.data.mode === 'public_request';
  }

  get dialogTitle(): string {
    if (this.data.title) {
      return this.data.title;
    }

    if (this.isPublicRequestMode) {
      return '📝 Register for Library Membership';
    }

    if (this.data.seat?.seat_no) {
      return `📝 Register Student - Seat ${this.data.seat.seat_no}`;
    }

    return '📝 Register Student';
  }

  get submitButtonLabel(): string {
    if (this.data.submitLabel) {
      return this.data.submitLabel;
    }

    return this.isPublicRequestMode ? '✓ Submit Request' : '✓ Register Student';
  }

  private shouldLookupExistingStudent(): boolean {
    if (typeof this.data.allowExistingStudentLookup === 'boolean') {
      return this.data.allowExistingStudentLookup;
    }

    return !this.isPublicRequestMode;
  }

  ngOnInit() {
    const today = startOfDay(new Date());
    // Calculate end date: today + days in current month - 1 using date-fns
    const daysInMonth = getDaysInMonth(today);
    const endDate = addDays(today, daysInMonth - 1);

    // Determine default shift based on seat availability
    let defaultShift = 'full_time';
    const seat = this.data.seat;
    
    if (!seat || (!seat.full_time_student_id && !seat.first_half_student_id && !seat.second_half_student_id)) {
      defaultShift = 'full_time';
    } else if (seat.first_half_student_id && !seat.second_half_student_id) {
      defaultShift = 'second_half';
    } else if (seat.second_half_student_id && !seat.first_half_student_id) {
      defaultShift = 'first_half';
    }

    this.registrationForm = this.fb.group({
      name: ['', Validators.required],
      mobile: [
        this.data.canViewPersonalDetails ? '' : 'N/A', 
        this.data.canViewPersonalDetails ? [Validators.required, Validators.pattern(/^[0-9]{10}$/)] : []
      ],
      emergency_contact: ['', (control: any) => {
        const value = control.value;
        if (!value || value.trim() === '') {
          return null; // No validation if empty
        }
        return /^[0-9]{10}$/.test(value) ? null : { pattern: true };
      }],
      emergency_contact_name: [''],
      address: [this.data.canViewPersonalDetails ? '' : 'N/A', this.data.canViewPersonalDetails ? Validators.required : []],
      dob: [null],
      gender: ['Male'],
      startDate: [today, Validators.required],
      endDate: [endDate, Validators.required],
      registration_fee_paid: [0],
      notes: [''],
      selectedShift: [defaultShift],
      feeAmount: [defaultShift === 'full_time' ? 400 : 250, [Validators.required, Validators.min(1)]],
      paymentMode: ['cash'],
      isPaymentReceived: [!this.isPublicRequestMode]
    });

    // Flatpickr removed. Will use Angular Material pickers.

    // Auto-adjust end date when start date changes
    this.registrationForm.get('startDate')?.valueChanges.subscribe(startDate => {
      if (startDate && startDate instanceof Date) {
        // Get days in the start month using date-fns
        const daysInMonth = getDaysInMonth(startDate);
        
        // Calculate end date: start date + days in month - 1
        const endDate = addDays(startDate, daysInMonth - 1);
        
        this.registrationForm.patchValue({ endDate }, { emitEvent: false });
      }
    });
    
    // Auto-fill form when mobile number is entered
    if (this.shouldLookupExistingStudent()) {
      this.registrationForm.get('mobile')?.valueChanges.subscribe(async mobile => {
        if (mobile && mobile.length === 10 && /^[0-9]{10}$/.test(mobile)) {
          try {
            const existingStudent = await this.libraryService.getStudentByMobile(mobile);
            if (existingStudent) {
              // Pre-fill the form with existing student data
              this.registrationForm.patchValue({
                name: existingStudent.name || '',
                emergency_contact: existingStudent.emergency_contact || '',
                emergency_contact_name: existingStudent.emergency_contact_name || '',
                address: existingStudent.address || '',
                dob: existingStudent.dob ? new Date(existingStudent.dob) : null,
                gender: existingStudent.gender || 'Male',
                notes: existingStudent.notes || ''
              }, { emitEvent: false });
            }
          } catch (error) {
            console.error('Error fetching student by mobile:', error);
          }
        }
      });
    }
  }

  onDateRangeChange() {
    const startDate = this.registrationForm.get('startDate')?.value;
    if (startDate && startDate instanceof Date) {
      // Get days in the start month using date-fns
      const daysInMonth = getDaysInMonth(startDate);
      
      // Calculate end date: start date + days in month - 1
      const endDate = addDays(startDate, daysInMonth - 1);
      
      this.registrationForm.patchValue({ endDate }, { emitEvent: false });
    }
  }

  onShiftChange() {
    const shift = this.registrationForm.get('selectedShift')?.value;
    const feeMap: { [key: string]: number } = {
      'full_time': 400,
      'first_half': 250,
      'second_half': 250
    };
    this.registrationForm.patchValue({ feeAmount: feeMap[shift] || 400 });
  }

  isShiftAvailable(shift: 'full_time' | 'first_half' | 'second_half'): boolean {
    const seat = this.data.seat;

    if (!seat) {
      return true;
    }
    
    if (shift === 'full_time') {
      return !seat.full_time_student_id && !seat.first_half_student_id && !seat.second_half_student_id;
    } else if (shift === 'first_half') {
      return !seat.full_time_student_id && !seat.first_half_student_id;
    } else if (shift === 'second_half') {
      return !seat.full_time_student_id && !seat.second_half_student_id;
    }
    
    return false;
  }

  onCancel() {
    this.dialogRef.close();
  }

  onSubmit() {
    if (this.registrationForm.valid) {
      this.dialogRef.close(this.registrationForm.value);
    }
  }
}
